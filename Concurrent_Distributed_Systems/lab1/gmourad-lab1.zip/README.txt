To run this program type "go build main" in the terminal, then enter "./main", to run the program

Once the program has been run, you will be prompted with the number of groups you want to send through, followed by the corresponding group sizes and delays. There is no delay for the last group as there are no groups afterwards. 
Next you will be prompted the chance of the vehicles taking the southbound direction which by default you may enter 0.5. The northbound with take the corresponding value that adds to 1. 
Finally you will be prompted with the chance of the vehicle being a car. Trucks will take the corresponding value that adds to 1.1